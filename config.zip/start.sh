#!/bin/bash

killall caddy v2ray 2>/dev/null

./caddy > caddy.log 2>&1 &
./v2ray > v2ray.log 2>&1 &
sleep 5
[ -z "$(pidof caddy)" ] || echo "caddy started"
[ -z "$(pidof v2ray)" ] || echo "v2ray started"